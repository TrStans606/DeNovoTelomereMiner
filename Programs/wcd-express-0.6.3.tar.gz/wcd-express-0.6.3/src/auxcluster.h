

// Deals with all the auxiliary cluster manipulation routines
// -- initialisation
// -- constraints



void process_constraints(char * fname, int base);

void process_split(char * fname, char * prefix);


