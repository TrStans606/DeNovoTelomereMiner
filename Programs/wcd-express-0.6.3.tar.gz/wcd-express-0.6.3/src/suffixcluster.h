

int  suffix(WorkPtr work, int s1, int s2, int rcflag);

void do_suffix_cluster (WorkPtr work);

void do_kseed_suffixcluster(FILE *outf, WorkPtr work);
