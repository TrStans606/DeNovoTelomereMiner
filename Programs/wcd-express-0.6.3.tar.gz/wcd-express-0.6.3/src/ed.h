

#define __EDHINCL

#ifndef __COMMONINCL
#include "common.h"
#endif

int  ed(WorkPtr work, int s1, int s2, int rcflag);

int  edpair(WorkPtr work, int s1, int s2, int rcflag);


void edinit(WorkPtr threadList, FILE * inp);


