#include "muscle.h"

void Usage(FILE *f)
	{
	PrintBanner(f);
	fprintf(f,
#include "usage.h"
	);
	}
