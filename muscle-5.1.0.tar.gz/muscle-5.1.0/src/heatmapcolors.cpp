
const char *g_HeatmapColors_HTML[10] =
	{
	"ff6464",
	"ff7878",
	"ff9696",
	"ffbebe",
	"ffe6e6",
	"ffffff",
	"e8f6f9",
	"d1f2f9",
	"a4f3fc",
	"98e8f9"
	};

const char *g_HeatmapColors_JalView[10] =
	{
	"A00000",
	"902020",
	"803030",
	"703030",
	"603030",
	"404040",
	"407040",
	"308030",
	"009000",
	"00A000"
	};
